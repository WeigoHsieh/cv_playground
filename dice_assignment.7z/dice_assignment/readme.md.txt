Hi, I am a student form Taiwan.

Fist of all.I am sorry for my bad English.

You can see my code index_finished.py in this folder.

My project is Dice_detection.

Now I can detect most dice pip in normal situation.

but I got stuck in 6 pics situation and have no idea to solve those problem.

You can see those case example pics in this folder.

They are: 

	-strong light example_9
		-strong light tilt zoom out example_6
		
	-zoom out tilt exmaple_10
	
	-dark tilt example_11

	-kmeans cluster problem: 2 dices example_12

	-kmeans cluster problem: 1 dices exmaple_13
		


Can you help me solving those case?
and what's the price? Thank you a lot.

ps. I find the dice template in the dice_groups, just in case.